/*
 *  File name: main.cpp
 *	Code explanation: OpenCV Algorithm for Background subtraction with the Raspberry Pi and Raspicam
 
 *	Source: http://docs.opencv.org/3.1.0/d1/dc5/tutorial_background_subtraction.html#gsc.tab=0
 *  Created on: Mar 24, 2016
 *  Author: streitfr
 */

//C++
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <map>
#include <list>
#include <cmath>
#include <vector>

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/sendfile.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <arpa/inet.h>

#include <errno.h>

#include <cstring>


//#include "SocketConnection.h"


#define portno 60000 // port number to use
#define buf_size 4096 // max file size to receive

using namespace std;

int rc; // holds return code of system calls
int sock; // socket desciptor
int desc; // file descriptor for socket
int path;                           // file descriptor for file to send

char const* fr_name = "./path.txt"; // path to file
off_t offset; 						// file offset
struct stat stat_buf;               // argument to fstat

/********************************************************
 *
 * Create socket and bind if successful created
 *
 *********************************************************/
void bindSocket() {
    struct sockaddr_in serv_addr;       // structure containing server address

    /* enable keep-alive on the socket */
    int one = 1;
    setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof(one));

    int idletime = 120; /* in seconds */
    setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE, &idletime, sizeof(idletime));

    /* First call to socket() function */
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        fprintf(stderr, "unable to create socket: %s\n", strerror(errno));
        exit(1);
    }

    /* fill in socket structure */
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    /* Now bind the host address using bind() call.*/
    rc = bind(sock, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
    if (rc == -1) {
        fprintf(stderr, "unable to bind to socket: %s\n", strerror(errno));
        exit(1);
    }
}

bool sendPath(char const* filename) {

	/* open the file to be sent */
	path = open(filename, O_RDONLY);

	if (path == -1) {
		cout << "ERROR unable to open or find file " << filename << endl;
		return 0;
	}

	/* get the size of the file to be sent */
	fstat(path, &stat_buf);

	offset = 0; // set offset to zero
	/* copy file using sendfile */
	for (size_t size_to_send = stat_buf.st_size; size_to_send > 0;) {
		ssize_t send = sendfile(desc, path, &offset, stat_buf.st_size);
			if (send == -1) {
				cout << "ERROR from sendfile" << endl;
				return 0;
			}
		offset += send;
		size_to_send -= send;
	}

	cout << "Done sending" << endl;
	/* close descriptor for file that was sent */
	close(path);

	return 1;
}


int main(int argc, char **argv) {

	// start of server sockets
/*
	SocketConnection connection;
	

	string path_file = "./path.txt";
	bool Server_con = connection.setupServer();
	bool send = false;
	send = connection.sendPath(path_file.c_str());
*/
// end of server sockets

	int fd_path; // filedescriptor for path
    struct sockaddr_in client_addr; // structure containing client address
    unsigned int clilen = sizeof(client_addr);

      bindSocket();

        rc = listen(sock, 1); // listening for the client only one client is allowed
        if (rc == -1) {
            fprintf(stderr, "listen failed: %s\n", strerror(errno));
            exit(1);
        }

   desc = accept(sock, (struct sockaddr *) &client_addr, &clilen);
        if (desc == -1) {
            fprintf(stderr, "accept failed: %s\n", strerror(errno));
            exit(1);
        } else {
            cout << "Connection accept from address "
                 << inet_ntoa(client_addr.sin_addr) << endl;
        }

	string path_file = "./path.txt";
	bool send = false;
	send = sendPath(path_file.c_str());

	close(sock);
}
