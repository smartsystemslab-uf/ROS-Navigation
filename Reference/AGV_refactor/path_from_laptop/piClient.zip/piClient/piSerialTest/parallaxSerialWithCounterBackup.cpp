#include <stdio.h>            // Recommended over iostream for saving space
#include <propeller.h>        // Propeller-specific functions

#include "simpletools.h"
#include "abdrive.h"
#include "fdserial.h"

const char STOP = '9';
const char FORWARD = '0';
const char RIGHT_TURN = '1';
const char LEFT_TURN = '7';


int main()                                    // main function
{

	int partialMoveCounter = 0;

    char moves[100];
  for(int i = 0; i < 100; i++){
    moves[i] = STOP;
  }
  int currentMoveIndex = 0;
  int lastMoveIndex = 0;
    char immediateMove = STOP;

  /* start device */
                  fdserial *term = fdserial_open(31,30,0,115200);

    while(1){

             int setPath = input(3);                    // P3 input -> button variable
              //print("setPath = %d\n", setPath);           // Display button state
              int goPin = input(4);                    // P4 input -> button variable
             // print("goPin = %d\n", goPin);           // Display button state
              int clearPath = input(5);                    // P5 input -> button variable
              //print("clearPath = %d\n", clearPath);           // Display button state
              pause(10);


              if( setPath && clearPath ) {

		  currentMoveIndex = 0;
                  lastMoveIndex = 0;
                  immediateMove = FORWARD;
                
                  //writeStr(term, "opened fdserial!\n\n");

                  while( immediateMove != STOP ){
                      //writeStr(term," while != q \n");

                      //wait until data is available
                      while(fdserial_rxReady(term) == 0);
                      moves[lastMoveIndex] = readChar(term);
                      immediateMove = moves[lastMoveIndex];
                      lastMoveIndex++;
                      //  writeStr(term,"char received \n");
                  }

                    //ignore the q that was sent to terminate the path

                  lastMoveIndex--;

                    //writeStr(term,"out of while ! = q \n");

                  //transmit the total number of steps received
                  //back to the raspberry pi
                  fdserial_txChar(term, lastMoveIndex);

                  immediateMove = readChar(term);
                    // The following block is a useful bit of debugging code to dump the received path to a console.
                    /*
                      int temp = 0;
                     while(temp<lastMoveIndex){
                       writeStr(term,"moves = ");
                        writeChar(term, moves[temp]);
                        writeStr(term, "\n");
                        temp++;
                    //    writeChar(term, );
                      //
                       //
                      }
                    */

              }//end of if setPath and clearPath




          //drive_setRampStep(10);                      // 10 ticks/sec / 20 ms

          //drive_ramp(128, 128);


          while(goPin )                                    // Endless loo  p
            {

                 // if( currentMoveIndex > 99 )
                   // currentMoveIndex = 0;

                  if(lastMoveIndex != currentMoveIndex){
			if ( partialMoveCounter > 9){
                      		immediateMove = moves[currentMoveIndex];
                      		moves[currentMoveIndex++] = STOP;
				partialMoveCounter = 0;
			}
			else{
				partialMoveCounter++;
			}
                    }
                  else{
                      immediateMove = STOP;
                      fdserial_txChar(term, currentMoveIndex);
                  }


                if( immediateMove == FORWARD ){
                    drive_speed(72, 72);
                    pause(50);

                }
                else if( immediateMove == LEFT_TURN ){
                //    drive_speed(-26, 26);
                    drive_speed(23, 72);
                    pause(50);
                }
                else if( immediateMove == RIGHT_TURN ){
               //     drive_speed(26, -26);
                         drive_speed(72, 23);
                    pause(50);
                }
                else if( immediateMove == STOP ){
                    drive_ramp(0,0);
                }


                goPin = input(4);
                // print("imediateMove = %c\n", immediateMove);
            }//end of while goPin
        drive_ramp(0,0);
    }// end of while(1)
// Close the serial connection.
                  fdserial_close(term);
// end of main
}
