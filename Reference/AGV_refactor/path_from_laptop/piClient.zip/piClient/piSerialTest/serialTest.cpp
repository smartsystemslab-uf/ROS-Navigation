
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <map>
#include <list>
#include <cmath>
#include <vector>

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <arpa/inet.h>


#include <wiringPi.h>
#include <wiringSerial.h>
#include <errno.h>

#include <cstring>

using namespace std;

char const* fr_name = "./path.txt"; // path to file

/********************************************************
 *
 * read data from text-file and write into vector
 *
 *********************************************************/
vector<u_char> readData() {
    char * line = NULL;
    size_t len = 0;
    FILE *path;
	vector<u_char> pathVector;

    path = fopen(fr_name, "r");
    if (path == NULL) {
        fprintf(stderr, "unable to open '%s': %s\n", path, strerror(errno));
        exit(1);
    }

    // read txt file line by line and write it into vector
    while ((getline(&line, &len, path)) != -1) {
        //read file into array
        pathVector.push_back(*line); //use vector for easier processing
    }

    fclose(path);
    cout << "close File" << endl;
    if (line)
        free(line);
	return pathVector;
}


int setPath(int propComms, vector<u_char> path ){
	int numSteps;

	//digitalWrite(1, LOW);
  	digitalWrite(23, HIGH);
  	digitalWrite(24, HIGH);

	//serialFlush(propComms);

	int catchKey = serialGetchar(propComms) & 0x7F;

//	int wtf = atoi(catchKey);
//	cin >> catchKey;
	cout << "char received indicating propellor serial ready : ";
	cout << catchKey << endl;

	digitalWrite(23, LOW);
    	digitalWrite(24, LOW);

	for(int i = 0; i < path.size(); i++){
		serialPutchar(propComms, path.at(i));
	}

	

	serialPutchar(propComms, '9');

 

	 catchKey = serialGetchar(propComms) & 0x7F;

//	int wtf = atoi(catchKey);
//	cin >> catchKey;
	cout << "Numsteps returned by propellor : ";
	cout << catchKey << endl;

	return numSteps;
}

void runPath(int propComms){


	digitalWrite(1, HIGH);
	

	serialPutchar(propComms, '9');

	int catchKey = serialGetchar(propComms) & 0x7F;
	    cout << "Value returned by propellor : ";
	    cout << catchKey << endl;
 
	digitalWrite(1, LOW);

	//serialFlush(propComms);

}

void closeSerial(int propComms){

	
	serialFlush(propComms);

//	printf("%c - %d", catchKey, catchKey);
	serialClose(propComms);

	cout << "closed serial \n";

}

int main(){



//
// serial test
//
//
	wiringPiSetup();
	

	int propComms = serialOpen("/dev/ttyUSB0", 115200);

	if( propComms == -1 )
		cout << "Failed to open serial port. :( \n";



	serialFlush(propComms);

int catchKey;// = serialGetchar(propComms) & 0x7F;

//	int wtf = atoi(catchKey);
//	cin >> catchKey;
	
	cout << "sizeof(int): " << sizeof(int) << endl;
	char a[sizeof(int)];
	
	int keyPress = -99;
	while(keyPress < 200){
		cout << "enter something to send : " << keyPress << endl;
		//cin >> keyPress;
		sprintf(a, "%d", keyPress);
		for(int i = 0; i < sizeof(int); i++){
			serialPutchar(propComms, a[i]);

		}
keyPress++;
sprintf(a, "%d", keyPress);
		for(int i = 0; i < sizeof(int); i++){
			serialPutchar(propComms, a[i]);

		}

			for(int i = 0; i < sizeof(int); i++){
			a[i] = serialGetchar(propComms);

		}
	sscanf(a, "%d", &catchKey);
cout << "char received : ";
	cout << catchKey << endl;
keyPress++;
	}
	


	closeSerial(propComms);

 	
//
return 0;
}
